package com.example.slaroub.applibar;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.maps.model.LatLng;

import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class creationProfil extends AppCompatActivity {
    RadioButton rbx1;
    RadioButton rbx2;
    RadioButton rbx3;
    RadioButton rbx4;
    DBAdapter db;
    String emailvalide;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creation_profil);
        Typeface custFont = Typeface.createFromAsset(getAssets(),"fonts/Funny & Cute.ttf");
        EditText e1 = (EditText) findViewById(R.id.etP1);
        ((View)findViewById(R.id.place_autocomplete_search_button)).setVisibility(View.GONE);
        ((View)findViewById(R.id.place_autocomplete_clear_button)).setBackgroundColor(Color.CYAN);

        EditText e2 = (EditText) findViewById(R.id.etP2);

        e1.setTypeface(custFont);
        e2.setTypeface(custFont);

        TextView tChoix = (TextView) findViewById(R.id.eChoix);
        tChoix.setTypeface(custFont);
        tChoix.setBackgroundColor(Color.CYAN);
        tChoix.setTextColor(R.color.fondET);

        CheckBox c1 = (CheckBox) findViewById(R.id.cb1);
        CheckBox c2 = (CheckBox) findViewById(R.id.cb2);
        CheckBox c3 = (CheckBox) findViewById(R.id.cb3);
        CheckBox c4 = (CheckBox) findViewById(R.id.cb4);

        c1.setTypeface(custFont);
        c2.setTypeface(custFont);
        c3.setTypeface(custFont);
        c4.setTypeface(custFont);


        c1.setTextColor(Color.WHITE);
        c2.setTextColor(Color.WHITE);
        c3.setTextColor(Color.WHITE);
        c4.setTextColor(Color.WHITE);
        // EditText e2 = (EditText) findViewById(R.id.etP2);

        initaliseET(e1);
        initaliseET(e2);
        emailvalide ="^["+"\\"+"w.+"+"\\"+"-]+@gmail"+"\\"+".com$";

        db = new DBAdapter(this,"",null,1);

        final PlaceAutocompleteFragment places= (PlaceAutocompleteFragment)
                getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment);






        places.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                EditText etPlace = (EditText)places.getView().findViewById(R.id.place_autocomplete_search_input);
                ((View)findViewById(R.id.place_autocomplete_search_button)).setVisibility(View.GONE);
                ((View)findViewById(R.id.place_autocomplete_clear_button)).setBackgroundColor(Color.CYAN);

                etPlace.setGravity(Gravity.CENTER);
                etPlace.setBackgroundColor(Color.CYAN);
                String str = (String) place.getName();
                str.replace('é','e');
                etPlace.setText(str);
                etPlace.setTextColor(R.color.fondET);
                //places.setText(place.getName());
               // Toast.makeText(getApplicationContext(),place.getName(),Toast.LENGTH_SHORT).show();




            }

            @Override
            public void onError(Status status) {

                Toast.makeText(getApplicationContext(),status.toString(),Toast.LENGTH_SHORT).show();

            }
        });



        EditText etPlace2 = (EditText)places.getView().findViewById(R.id.place_autocomplete_search_input);


        ((View)findViewById(R.id.place_autocomplete_search_button)).setVisibility(View.GONE);
        ((View)findViewById(R.id.place_autocomplete_clear_button)).setBackgroundColor(Color.CYAN);
        etPlace2.setGravity(Gravity.CENTER);
        etPlace2.setBackgroundColor(Color.CYAN);
        etPlace2.setTypeface(custFont);
        etPlace2.setHint("Entrez l'adresse");
        etPlace2.setHintTextColor(R.color.fondET);





    }

    private void initaliseET(EditText e1) {
        e1.setTextColor(Color.BLACK);
        e1.setHintTextColor(R.color.fondET);
        e1.setBackgroundColor(Color.CYAN);
    }


    public void validerPro(View view) {
        EditText e2 = (EditText) findViewById(R.id.etP2);
        EditText e1 = (EditText) findViewById(R.id.etP1);
        final PlaceAutocompleteFragment places = (PlaceAutocompleteFragment)
                getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment);
        EditText etPlace2 = (EditText) places.getView().findViewById(R.id.place_autocomplete_search_input);

        if(db.nomDispo(e1.getText().toString())){
            Matcher matcher = Pattern.compile(emailvalide).matcher((e2.getText().toString()));
            if (matcher.matches()) {
                if (e1.getText().toString().equalsIgnoreCase("") || e2.getText().toString().equalsIgnoreCase("") || etPlace2.getText().toString().equalsIgnoreCase("")) {
                    AlertDialog.Builder dialog = new AlertDialog.Builder((creationProfil.this));


                    dialog.setTitle("Attention !");
                    dialog.setMessage("Veuillez remplir tous les champs");


                    dialog.setPositiveButton("Compris !", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    dialog.show();
                } else {


                    String nom;
                    String adresse;
                    String madresse;
                    int jap, ind, ita, chi;


                    nom = e1.getText().toString();


                    adresse = etPlace2.getText().toString();


                    madresse = e2.getText().toString();

                    CheckBox c1 = (CheckBox) findViewById(R.id.cb1);
                    CheckBox c2 = (CheckBox) findViewById(R.id.cb2);
                    CheckBox c3 = (CheckBox) findViewById(R.id.cb3);
                    CheckBox c4 = (CheckBox) findViewById(R.id.cb4);

                    if (c1.isChecked()) {
                        ind = 1;
                    } else ind = 0;

                    if (c2.isChecked()) {
                        ita = 1;
                    } else ita = 0;

                    if (c3.isChecked()) {
                        chi = 1;
                    } else chi = 0;

                    if (c4.isChecked()) {
                        jap = 1;
                    } else jap = 0;

                    db.insertProfile(nom, adresse, madresse, jap, ita, ind, chi);


                    db.close();
                    Intent intent = new Intent(this, DisplayActivity.class);
                    startActivity(intent);
                }
            } else {
                AlertDialog.Builder dialog = new AlertDialog.Builder((creationProfil.this));


                dialog.setTitle("Attention !");
                dialog.setMessage("Veuillez entrer une adresse gmail correcte pour recevoir votre récapitulatif");


                dialog.setPositiveButton("Compris !", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        }else{
            AlertDialog.Builder dialog = new AlertDialog.Builder((creationProfil.this));


            dialog.setTitle("Attention !");
            dialog.setMessage("Le nom choisi est déja pris");


            dialog.setPositiveButton("Compris !", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            dialog.show();
        }
    }


    public LatLng getLocationFromAddress(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }
}



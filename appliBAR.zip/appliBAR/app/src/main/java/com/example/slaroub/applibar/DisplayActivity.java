package com.example.slaroub.applibar;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DisplayActivity extends AppCompatActivity {
    EditText eT1;
    EditText eT2;
    EditText eT3;
    Spinner spinner;
    Intent intent;
    Intent intent2;
    Intent intent3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        Typeface custFont = Typeface.createFromAsset(getAssets(),"fonts/Funny & Cute.ttf");

        TextView tv1 = (TextView) findViewById(R.id.tvCrea );
        TextView tv2 = (TextView) findViewById(R.id.tvSoiree );
        TextView tv3 = (TextView) findViewById(R.id.tvSuppr );

        tv1.setTextColor(Color.WHITE);
        tv2.setTextColor(Color.WHITE);
        tv3.setTextColor(Color.WHITE);

        tv1.setTypeface(custFont);
        tv2.setTypeface(custFont);
        tv3.setTypeface(custFont);

        intent = new Intent(this, creationDeSoiree.class);
        intent2 = new Intent(this, creationProfil.class);
        intent3 = new Intent(this, supprimerProfil.class);


    }


    public void creaProfil(View view) {
        TextView tv1 = (TextView) findViewById(R.id.tvCrea );
        tv1.setTextColor(Color.GRAY);
        retard2();

    }

    public void creaSoiree(View view) {
        TextView tv2 = (TextView) findViewById(R.id.tvSoiree );
        tv2.setTextColor(Color.GRAY);

        retard();
    }

    public void supprProfil(View view) {
        TextView tv3 = (TextView) findViewById(R.id.tvSuppr );
        tv3.setTextColor(Color.GRAY);

        retard3();
    }

    public void retard(){
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms
                TextView tv2 = (TextView) findViewById(R.id.tvSoiree );
                tv2.setTextColor(Color.WHITE);
                startActivity(intent);
            }
        }, 100);

    }

    public void retard2(){
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms
                TextView tv1 = (TextView) findViewById(R.id.tvCrea );
                tv1.setTextColor(Color.WHITE);
                startActivity(intent2);
            }
        }, 100);

    }

    public void retard3(){
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms
                TextView tv3 = (TextView) findViewById(R.id.tvSuppr );
                tv3.setTextColor(Color.WHITE);
                startActivity(intent3);
            }
        }, 100);

    }
}

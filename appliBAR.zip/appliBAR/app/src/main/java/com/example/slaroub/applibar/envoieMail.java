package com.example.slaroub.applibar;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class envoieMail extends AppCompatActivity {
TextView feli;
TextView expli;
TextView sam;
String s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_envoie_mail);


        Bundle bundle = getIntent().getExtras();
        String s = bundle.getString("sam");
        final Typeface custFont = Typeface.createFromAsset(getAssets(),"fonts/Funny & Cute.ttf");

        feli = findViewById(R.id.tvFeli);
        feli.setTypeface(custFont);
        feli.setTextColor(Color.BLACK);
        feli.setText("Felicitations !");
        feli.setGravity(Gravity.CENTER);

        expli = findViewById(R.id.tvExpli);
        expli.setTypeface(custFont);
        expli.setTextColor(Color.WHITE);
        expli.setText("Un email a ete envoye aux participants");
        expli.setGravity(Gravity.CENTER);


        sam = findViewById(R.id.tvSam);
        sam.setTypeface(custFont);
        sam.setTextColor(Color.WHITE);
        sam.setText(s+" sera votre Sam pour la soiree !");
        sam.setGravity(Gravity.CENTER);
    }


}

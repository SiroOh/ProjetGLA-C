package com.example.slaroub.applibar;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.ViewFlipper;

import static android.graphics.Typeface.*;
import static com.example.slaroub.applibar.R.drawable.chopevide;
import static com.example.slaroub.applibar.R.raw.biere;
import static java.lang.Thread.sleep;

public class MainActivity extends AppCompatActivity {

    ProgressBar bdp;
    TextView tB;
    ConstraintLayout cL;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bdp = (ProgressBar) findViewById(R.id.barreDeP);
        bdp.setProgressTintList(ColorStateList.valueOf(Color.WHITE));
        final Typeface custFont = Typeface.createFromAsset(getAssets(),"fonts/Funny & Cute.ttf");
        tB = (TextView) findViewById(R.id.textebdp);
        tB.setText("Chargement de l'application...");
        tB.setTextColor(Color.BLACK);
        tB.setTypeface(custFont);
        tB.setGravity(Gravity.CENTER);

        cL = (ConstraintLayout) findViewById(R.id.ecran);
        blink();
        BarreDeProgres barre = new BarreDeProgres();
        barre.execute();

    }

    public void blink(){
        ImageView titre = (ImageView) findViewById(R.id.titreNight);
        Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(800);
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        titre.startAnimation(anim);

    }

    private class BarreDeProgres extends AsyncTask<Void, Integer, Void>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();


        }

        @Override
        protected void onProgressUpdate(Integer... values){
            super.onProgressUpdate(values);
            bdp.setProgress(values[0]);


        }


        @Override
        protected Void doInBackground(Void... voids) {

            for(int P = 0; P <100; P++){

                try {
                    sleep(30);

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }


                publishProgress(P);
                try{
                    if(P==20){
                        tB.setText("Nettoyage des verres...");
                    }
                    if(P==60){
                        tB.setText("Preparation des couverts...");
                    }
                    if(P==80){
                        tB.setText("Depoussierage du sol...");
                    }
                }
                catch (Exception e) {
                }

            }
            return null;
        }


        @Override
        protected void onPostExecute(Void result) {
            bdp.setVisibility(View.GONE);
            bdp.setVisibility(View.INVISIBLE);
            tB.setVisibility(View.INVISIBLE);
            cL.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final MediaPlayer mp = MediaPlayer.create(MainActivity.this, R.raw.biere);
                    mp.start();
                    Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
                    startActivity(intent);
                }
            });

        }
    }
    /*
    public void blinkText2(){
        TextView myText = (TextView) findViewById(R.id.tv );
        Typeface custFont = Typeface.createFromAsset(getAssets(),"fonts/Funny & Cute.ttf");
        myText.setTypeface(custFont);
        myText.setTextColor(Color.WHITE);
        ImageView img = (ImageView) findViewById(R.id.iV);

        Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(1000); //You can manage the time of the blink with this parameter
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        img.startAnimation(anim);
        myText.startAnimation(anim);
    }
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void gling(View view) {

        final MediaPlayer mp = MediaPlayer.create(this, R.raw.biere);
        mp.start();
        Intent intent = new Intent(this, DisplayActivity.class);
        startActivity(intent);

    }
    */

}

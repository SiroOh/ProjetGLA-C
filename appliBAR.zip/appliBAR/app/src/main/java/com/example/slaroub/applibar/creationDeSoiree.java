package com.example.slaroub.applibar;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class creationDeSoiree extends AppCompatActivity {

    DBAdapter db;
    TextView tvListe;
    TextView tvIvs;
    ImageView ivPlus;
    ImageView ivMoins;

    ImageView ivPlus2;
    TextView tvIvs2;
    ImageView ivMoins2;

    ImageView ivPlus3;
    TextView tvIvs3;
    ImageView ivMoins3;


    Boolean but1;
    Boolean but2;
    Boolean but3;

    ArrayList<String> listeExclusions;

    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creation_de_soiree);


        db = new DBAdapter(this,"",null,1);
        listeExclusions = new ArrayList<String>();
        Typeface custFont = Typeface.createFromAsset(getAssets(),"fonts/Funny & Cute.ttf");

        EditText e1 = (EditText) findViewById(R.id.etP1);
        EditText e2 = (EditText) findViewById(R.id.etP2);

        e1.setTypeface(custFont);
        e2.setTypeface(custFont);

        TextView tvAjouter = (TextView) findViewById(R.id.tvNvProfil);
        tvAjouter.setTextColor(R.color.fondET);
        tvAjouter.setBackgroundColor(Color.CYAN);
        tvAjouter.setTypeface(custFont);



        initaliseET(e1);
        initaliseET(e2);

        e1.setVisibility(View.INVISIBLE);
        e2.setVisibility(View.INVISIBLE);

        tvIvs = (TextView) findViewById(R.id.tvInvi);
        tvIvs2 = (TextView) findViewById(R.id.tvInvi2);
        tvIvs3 = (TextView) findViewById(R.id.tvInvi3);
        intent = new Intent(this, displaySoiree.class);

    }

    private void initaliseET(EditText e1) {
        e1.setTextColor(Color.BLACK);
        e1.setHintTextColor(R.color.fondET);
        e1.setBackgroundColor(Color.CYAN);
    }

    public void ajouter(final View view) {

        but1 = false;
        but2= false;
        but3= false;
        ivPlus = (ImageView) findViewById(R.id.btnPlus);
        ivMoins = (ImageView) findViewById(R.id.btnMoins);

        ivPlus2 = (ImageView) findViewById(R.id.btnPlus2);
        ivMoins2 = (ImageView) findViewById(R.id.btnMoins2);

        ivPlus3 = (ImageView) findViewById(R.id.btnPlus3);
        ivMoins3 = (ImageView) findViewById(R.id.btnMoins3);

        final Typeface custFont = Typeface.createFromAsset(getAssets(),"fonts/Funny & Cute.ttf");
        AlertDialog.Builder dialog = new AlertDialog.Builder((this));
        dialog.setTitle("Ajouter une personne a la soiree");
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(creationDeSoiree.this, android.R.layout.simple_list_item_single_choice);

        db.list_all_profiles(arrayAdapter);

        dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        dialog.setAdapter(arrayAdapter, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String strName = arrayAdapter.getItem(which);
                        AlertDialog.Builder builderInner = new AlertDialog.Builder(creationDeSoiree.this);
                        if (view.getId() == R.id.btnPlus  && (!(tvIvs2.getText().toString().equalsIgnoreCase(strName)) && (!(tvIvs3.getText().toString().equalsIgnoreCase(strName))))){
                            tvIvs.setTextColor(Color.WHITE);
                            tvIvs.setTypeface(custFont);
                            tvIvs.setVisibility(View.VISIBLE);
                            tvIvs.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                    AlertDialog.Builder dialog = new AlertDialog.Builder((creationDeSoiree.this));
                                    final ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(creationDeSoiree.this, android.R.layout.select_dialog_singlechoice);
                                    arrayAdapter2.add("Voiture");
                                    arrayAdapter2.add("Ferré");
                                    arrayAdapter2.add("A pieds");


                                    dialog.setTitle("Affecter un moyen de transport");
                                    final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(creationDeSoiree.this, android.R.layout.select_dialog_singlechoice);


                                    dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                                    dialog.show();
                                }
                            });

                            tvIvs.setText(strName);
                            ivPlus.setVisibility(View.INVISIBLE);
                            ivMoins.setVisibility(View.VISIBLE);
                            if(ivMoins2.getVisibility()==View.INVISIBLE){
                            ivPlus2.setVisibility(View.VISIBLE);
                            }
                        } else if (view.getId() == R.id.btnPlus2 && (!(tvIvs.getText().toString().equalsIgnoreCase(strName)) && (!(tvIvs3.getText().toString().equalsIgnoreCase(strName))))) {
                            tvIvs2.setTextColor(Color.WHITE);
                            tvIvs2.setTypeface(custFont);
                            tvIvs2.setVisibility(View.VISIBLE);
                            tvIvs2.setText(strName);
                            tvIvs2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    AlertDialog.Builder dialog = new AlertDialog.Builder((creationDeSoiree.this));
                                    dialog.setTitle("Affecter un moyen de transport");
                                    final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(creationDeSoiree.this, android.R.layout.select_dialog_singlechoice);

                                    db.list_all_profiles(arrayAdapter);

                                    dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                                    dialog.show();
                                }
                            });
                            ivPlus2.setVisibility(View.INVISIBLE);
                            ivMoins2.setVisibility(View.VISIBLE);
                            if(ivMoins3.getVisibility()==View.INVISIBLE){
                            ivPlus3.setVisibility(View.VISIBLE);}
                        } else if (view.getId() == R.id.btnPlus3 && (!(tvIvs.getText().toString().equalsIgnoreCase(strName)) && (!(tvIvs2.getText().toString().equalsIgnoreCase(strName))))) {
                            tvIvs3.setTextColor(Color.WHITE);
                            tvIvs3.setTypeface(custFont);
                            tvIvs3.setVisibility(View.VISIBLE);
                            tvIvs3.setText(strName);
                            tvIvs3.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    AlertDialog.Builder dialog = new AlertDialog.Builder((creationDeSoiree.this));
                                    dialog.setTitle("Affecter un moyen de transport");
                                    final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(creationDeSoiree.this, android.R.layout.select_dialog_singlechoice);

                                    db.list_all_profiles(arrayAdapter);

                                    dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                                    dialog.show();
                                }
                            });
                            ivPlus3.setVisibility(View.INVISIBLE);
                            ivMoins3.setVisibility(View.VISIBLE);
                            //ivPlus2.setVisibility(View.VISIBLE);
                        }





                dialog.dismiss();
            }
        });
        dialog.show();

    }






    public void retirer(View view) {
        if (view.getId()==R.id.btnMoins){

                tvIvs.setText("");
                tvIvs.setVisibility(View.INVISIBLE);
                ivMoins.setVisibility(View.INVISIBLE);
                ivPlus.setVisibility(View.VISIBLE);
            }else if(view.getId()==R.id.btnMoins2){

                tvIvs2.setText("");
                tvIvs2.setVisibility(View.INVISIBLE);
                ivMoins2.setVisibility(View.INVISIBLE);
                ivPlus2.setVisibility(View.VISIBLE);
            }else if(view.getId()==R.id.btnMoins3){

                tvIvs3.setText("");
                tvIvs3.setVisibility(View.INVISIBLE);
                ivMoins3.setVisibility(View.INVISIBLE);
                ivPlus3.setVisibility(View.VISIBLE);
            }
        }

    public void validerSoiree(View view) {
        AlertDialog.Builder dialog = new AlertDialog.Builder((creationDeSoiree.this));
        tvIvs = (TextView) findViewById(R.id.tvInvi);
        tvIvs2 = (TextView) findViewById(R.id.tvInvi2);
        tvIvs3 = (TextView) findViewById(R.id.tvInvi3);

        if ((tvIvs.getText().toString().isEmpty()) && (tvIvs2.getText().toString().isEmpty()) && (tvIvs3.getText().toString().isEmpty())){
            dialog.setTitle("Attention !");
            dialog.setMessage("Veuillez ajouter au moins un profil à la soirée.");


            dialog.setPositiveButton("Compris !", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();


                }
            });
            dialog.show();

        }
        else {

            dialog.setTitle("Generation de soiree");
            dialog.setMessage("Voulez vous generer une soiree ?");


            dialog.setPositiveButton("Generer", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ArrayList<String> aL = new ArrayList<>();
                    remplirProfils(aL);
                    listeExclusions = db.list_exclusions(aL);
                    intent.putExtra("liste", aL);
                    intent.putExtra("listeExclu", listeExclusions);
                    startActivity(intent);


                }
            });

            dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            dialog.show();
        }

    }

    public void remplirProfils(ArrayList<String> aList){
        tvIvs = (TextView) findViewById(R.id.tvInvi);
        tvIvs2 = (TextView) findViewById(R.id.tvInvi2);
        tvIvs3 = (TextView) findViewById(R.id.tvInvi3);

        if (!(tvIvs.getText().toString().isEmpty())){
            aList.add(tvIvs.getText().toString());
        }

        if (!(tvIvs2.getText().toString().isEmpty())){
            aList.add(tvIvs2.getText().toString());
        }

        if (!(tvIvs3.getText().toString().isEmpty())){
            aList.add(tvIvs3.getText().toString());
        }
    }
}

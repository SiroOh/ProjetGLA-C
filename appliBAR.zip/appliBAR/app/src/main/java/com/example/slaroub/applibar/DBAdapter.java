package com.example.slaroub.applibar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.inputmethodservice.Keyboard;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import java.util.ArrayList;

import static android.widget.LinearLayout.LayoutParams.*;

public class DBAdapter extends SQLiteOpenHelper
{
    public static final String KEY_NAME = "name";
    public static final String KEY_ADRESS = "adress";
    public static final String KEY_MAIL = "mailadress";
    public static final String K_JAP = "jap";
    public static final String K_ITA = "ita";
    public static final String K_IND = "ind";
    public static final String K_CHI = "chi";
    private static final String TAG = "DBAdapter";

    private static final String DATABASE_NAME = "dbprofil";
    private static final String DATABASE_TABLE = "profils";
    private static final int DATABASE_VERSION = 1;




    private SQLiteDatabase db;

    public DBAdapter(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "TEST.db", factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE PROFILS(NAME TEXT NOT NULL, ADRESS TEXT NOT NULL, MAILADRESS TEXT PRIMARY KEY, JAP INTEGER NOT NULL, ITA INTEGER NOT NULL, IND INTEGER NOT NULL, CHI INTEGER NOT NULL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS PROFILS;");
        onCreate(sqLiteDatabase);
    }



    public void insertProfile(String name, String adress, String mailadress, Integer jap, Integer ita, Integer ind, Integer chi)
    {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_NAME, name);
        initialValues.put(KEY_ADRESS, adress);
        initialValues.put(KEY_MAIL, mailadress);
        initialValues.put(K_JAP, jap);
        initialValues.put(K_ITA, ita);
        initialValues.put(K_IND, ind);
        initialValues.put(K_CHI, chi);
        this.getWritableDatabase().insertOrThrow("PROFILS","",initialValues);
    }


    /*
    public void list_all_profiles(TextView textView){
        Cursor crs = this.getReadableDatabase().rawQuery("SELECT * FROM PROFILS", null);
        textView.setText("");
        while (crs.moveToNext()){
            textView.append(crs.getString(0)+"\n");

        }


    }*/

    public void list_all_profiles(ArrayAdapter<String> aDAP){

        Cursor crs = this.getReadableDatabase().rawQuery("SELECT * FROM PROFILS", null);
       // textView.setText("");
        while (crs.moveToNext()){
            aDAP.add(crs.getString(0));


        }


    }

    public void list_all_adresses(ArrayList<String> aList){

        Cursor crs = this.getReadableDatabase().rawQuery("SELECT * FROM PROFILS", null);
        // textView.setText("");
        while (crs.moveToNext()){
            aList.add(crs.getString(1));

        }
    }


    public ArrayList list_adressesP(ArrayList<String> aList){
        ArrayList<String> aListe2 = new ArrayList<>();
        for(int i =0; i<aList.size();i++) {
            Cursor crs = this.getReadableDatabase().rawQuery("SELECT ADRESS FROM PROFILS WHERE NAME='"+aList.get(i).toString()+"';", null);
            while (crs.moveToNext()) {
                aListe2.add(crs.getString(0));
            }
        }
        return aListe2;
    }



    public void delete_student(){
        this.getWritableDatabase().delete("PROFILS","",null);

    }
    //---insert a profil in the db---
    public void delete_profile(String str){
        this.getWritableDatabase().delete("PROFILS","NAME='"+str+"'",null);

    }

    public ArrayList list_adressesMail(ArrayList<String> aList){
        ArrayList<String> aListe2 = new ArrayList<>();
        for(int i =0; i<aList.size();i++) {
            Cursor crs = this.getReadableDatabase().rawQuery("SELECT MAILADRESS FROM PROFILS WHERE NAME='"+aList.get(i).toString()+"';", null);
            while (crs.moveToNext()) {
                aListe2.add(crs.getString(0));
            }
        }
        return aListe2;
    }


}
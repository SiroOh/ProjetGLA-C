package com.example.slaroub.applibar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.inputmethodservice.Keyboard;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import java.util.ArrayList;

import static android.widget.LinearLayout.LayoutParams.*;

public class DBAdapter extends SQLiteOpenHelper
{
    public static final String KEY_NAME = "name";
    public static final String KEY_ADRESS = "adress";
    public static final String KEY_MAIL = "mailadress";
    public static final String K_JAP = "jap";
    public static final String K_ITA = "ita";
    public static final String K_IND = "ind";
    public static final String K_CHI = "chi";
    private static final String TAG = "DBAdapter";

    private static final String DATABASE_NAME = "dbprofil";
    private static final String DATABASE_TABLE = "profils";
    private static final int DATABASE_VERSION = 1;




    private SQLiteDatabase db;

    public DBAdapter(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "TEST.db", factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE PROFILS(NAME TEXT NOT NULL, ADRESS TEXT NOT NULL, MAILADRESS TEXT PRIMARY KEY, JAP INTEGER NOT NULL, ITA INTEGER NOT NULL, IND INTEGER NOT NULL, CHI INTEGER NOT NULL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS PROFILS;");
        onCreate(sqLiteDatabase);
    }



    public void insertProfile(String name, String adress, String mailadress, Integer jap, Integer ita, Integer ind, Integer chi)
    {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_NAME, name);
        initialValues.put(KEY_ADRESS, adress);
        initialValues.put(KEY_MAIL, mailadress);
        initialValues.put(K_JAP, jap);
        initialValues.put(K_ITA, ita);
        initialValues.put(K_IND, ind);
        initialValues.put(K_CHI, chi);
        this.getWritableDatabase().insertOrThrow("PROFILS","",initialValues);
    }


    /*
    public void list_all_profiles(TextView textView){
        Cursor crs = this.getReadableDatabase().rawQuery("SELECT * FROM PROFILS", null);
        textView.setText("");
        while (crs.moveToNext()){
            textView.append(crs.getString(0)+"\n");

        }


    }*/

    public void list_all_profiles(ArrayAdapter<String> aDAP){

        Cursor crs = this.getReadableDatabase().rawQuery("SELECT * FROM PROFILS", null);
       // textView.setText("");
        while (crs.moveToNext()){
            aDAP.add(crs.getString(0));


        }


    }

    public void list_all_adresses(ArrayList<String> aList){

        Cursor crs = this.getReadableDatabase().rawQuery("SELECT * FROM PROFILS", null);
        // textView.setText("");
        while (crs.moveToNext()){
            aList.add(crs.getString(1));

        }
    }


    public ArrayList list_adressesP(ArrayList<String> aList){
        ArrayList<String> aListe2 = new ArrayList<>();
        for(int i =0; i<aList.size();i++) {
            Cursor crs = this.getReadableDatabase().rawQuery("SELECT ADRESS FROM PROFILS WHERE NAME='"+aList.get(i).toString()+"';", null);
            while (crs.moveToNext()) {
                aListe2.add(crs.getString(0));
            }
        }
        return aListe2;
    }



    public void delete_student(){
        this.getWritableDatabase().delete("PROFILS","",null);

    }
    //---insert a profil in the db---
    public void delete_profile(String str){
        this.getWritableDatabase().delete("PROFILS","NAME='"+str+"'",null);

    }

    public ArrayList list_adressesMail(ArrayList<String> aList){
        ArrayList<String> aListe2 = new ArrayList<>();
        for(int i =0; i<aList.size();i++) {
            Cursor crs = this.getReadableDatabase().rawQuery("SELECT MAILADRESS FROM PROFILS WHERE NAME='"+aList.get(i).toString()+"';", null);
            while (crs.moveToNext()) {
                aListe2.add(crs.getString(0));
            }
        }
        return aListe2;
    }


    public modifierProfil.personne getProfil(String profil) {
        modifierProfil.personne p1 = new modifierProfil.personne();
        Cursor crs = this.getReadableDatabase().rawQuery("SELECT * FROM PROFILS WHERE NAME='"+profil +"';", null);

        if(crs!=null && crs.moveToFirst()) {
            p1.setNomPersonne(crs.getString(0));
            p1.setAdressePersonne(crs.getString(1));
            p1.setAdresseMailPersonne(crs.getString(2));
            p1.setJapPersonne(crs.getInt(3));
            p1.setItaPersonne(crs.getInt(4));
            p1.setIndPersonne(crs.getInt(5));
            p1.setChiPersonne(crs.getInt(6));
        }
        return  p1;
    }


    public void majProfil(String n, String nom, String adr, String adrm, int jap, int ita, int ind, int chi){
        ContentValues contenu = new ContentValues();
        contenu.put("NAME", nom);
        contenu.put("ADRESS", adr);
        contenu.put("MAILADRESS", adrm);
        contenu.put("JAP", jap);
        contenu.put("ITA", ita);
        contenu.put("IND", ind);
        contenu.put("CHI", chi);
        this.getWritableDatabase().update("PROFILS",contenu,"NAME='"+n+"'", null);
    }


    public ArrayList list_exclusions(ArrayList<String> listeProfils){
        ArrayList<String> liste2 = new ArrayList<>();
        for(int i =0; i<listeProfils.size();i++) {
            Cursor crs = this.getReadableDatabase().rawQuery("SELECT JAP,ITA,IND,CHI FROM PROFILS WHERE NAME='"+listeProfils.get(i).toString()+"';", null);
            while (crs.moveToNext()) {
                if(crs.getInt(0)==1){
                liste2.add("Japonais");
                liste2.add("Sushi");
                liste2.add("Japon");
                liste2.add("Tokyo");
                }
                if(crs.getInt(1)==1){
                    liste2.add("Italien");
                    liste2.add("Italienne");
                    liste2.add("Italy");
                    liste2.add("Rome");
                    liste2.add("Venise");
                }
                if(crs.getInt(2)==1){
                    liste2.add("Indien");
                    liste2.add("Indienne");
                    liste2.add("Indian");
                    liste2.add("Taj");
                    liste2.add("Maharajah");
                }
                if(crs.getInt(3)==1){
                    liste2.add("Chinois");
                    liste2.add("Chinoise");
                    liste2.add("Pékin");
                    liste2.add("Wok");
                    liste2.add("China");
                }

            }
        }
        return liste2;
    }


    public boolean nomDispo(String profil) {
        Cursor crs = this.getReadableDatabase().rawQuery("SELECT * FROM PROFILS WHERE NAME='"+profil +"';", null);

        if(crs.getCount()==0) {
            return true;
        }else return false;
    }


}
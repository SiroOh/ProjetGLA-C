package com.example.slaroub.applibar;

import android.content.Context;
import android.graphics.Typeface;

import java.lang.reflect.Field;
import java.lang.reflect.Type;

/**
 * Created by Sophiane on 02/02/2018.
 */

public class ReplaceFont {

    public static void replaceDefaultFont(Context context, String newFont){
        Typeface customFont = Typeface.createFromAsset(context.getAssets(), newFont);
        replaceFont("DEFAULT", customFont);
    }

    private static void replaceFont(String oldFont, Typeface customFont) {
        try {
            Field field = Typeface.class.getDeclaredField(oldFont);
            field.setAccessible(true);
            field.set(null, customFont);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

    }
}

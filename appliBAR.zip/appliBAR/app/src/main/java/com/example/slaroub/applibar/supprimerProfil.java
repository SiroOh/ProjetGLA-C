package com.example.slaroub.applibar;

import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class supprimerProfil extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supprimer_profil);
        final Typeface custFont = Typeface.createFromAsset(getAssets(),"fonts/Funny & Cute.ttf");




        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(supprimerProfil.this, android.R.layout.simple_selectable_list_item){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                ((TextView) v).setTextColor(R.color.fondET);
                ((TextView) v).setTypeface(custFont);
                ((TextView) v).setBackgroundColor(Color.CYAN);
                return v;
            }

            @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {
                // TODO Auto-generated method stub
                View v = super.getDropDownView(position, convertView, parent);
                ((TextView) v).setTextColor(R.color.fondET);
                ((TextView) v).setTypeface(custFont);
                ((TextView) v).setBackgroundColor(Color.WHITE);
                return v;
            }
        };
        final DBAdapter db = new DBAdapter(this,"",null,1);
        db.list_all_profiles(arrayAdapter);
        final ListView listView = (ListView) findViewById(R.id.listeDeGens);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> myAdapter, View myView, int myItemInt, long mylng) {
                final String selectedFromList =(String) (listView.getItemAtPosition(myItemInt));
                myView.setBackgroundColor(Color.GRAY);
                retard(myView);

                AlertDialog.Builder dialog = new AlertDialog.Builder((supprimerProfil.this));


                dialog.setTitle("Suppression d'un profil");
                dialog.setMessage("Voulez vous supprimer le profil de "+selectedFromList+ " ?");



                dialog.setPositiveButton("Confirmer", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        db.delete_profile(selectedFromList);

                        dialog.dismiss();
                        finish();
                        startActivity(getIntent());
                    }
                });

                dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                dialog.show();

            }
        });

        listView.setAdapter(arrayAdapter);
        TextView titre = findViewById(R.id.titreS);
        titre.setText("Choisir un profil a supprimer");
        titre.setTypeface(custFont);
        titre.setTextColor(Color.WHITE);
        titre.setGravity(Gravity.CENTER);




    }

    public void retard(final View v){
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                v.setBackgroundColor(Color.CYAN);
            }
        }, 100);

    }


}

package com.example.slaroub.applibar;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Random;
import java.util.Scanner;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import static java.lang.Thread.sleep;

public class displaySoiree extends AppCompatActivity {
    ArrayList<String> aListe;
    ArrayList<String> aListe2;
    ArrayList<String> aListeMail;
    DBAdapter db;
    GoogleMap mGoogleMap;
    LatLng rdv;
    private static String GooglePlacesKey = "AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs";
    String nomRecup, adresseRecup;
    Double pos1, pos2;
    String nomRecup2, adresseRecup2;

    String nomRecup3, adresseRecup3;
    String nomRest, adresseRest, nomBar, adresseBar, nomBoite, adresseBoite;
    String sa;
    Integer compteurAsynk=1;
    Integer rad =500;
    Integer rad2 = 500;
    Integer rad3 = 500;
    ArrayAdapter<String> arrayAdapter2;
    ListView lv;

    Boolean boolVide =false;

    ProgressBar pb;
    TextView tB, titre;
    AlertDialog.Builder dialog;

    ArrayList<endroits> end, end2, end3;
    String refIm, refIm2, refIm3;
    Bitmap bmp, bmp2,bmp3;
    ImageView photoEndroit, photoEndroit2, photoEndroit3;
    ImageView photoVide, photoVide2, photoVide3;

    ImageView boutonCarte, boutonValider;
    Boolean click1= false, click2 = false, click3=false;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_soiree);



        Intent intent = getIntent();
        aListe = intent.getStringArrayListExtra("liste");
        lv = findViewById(R.id.listePSoiree);
        final Typeface custFont = Typeface.createFromAsset(getAssets(),"fonts/Funny & Cute.ttf");
        pb = (ProgressBar) findViewById(R.id.progres);
        pb.setProgressTintList(ColorStateList.valueOf(Color.RED));
        tB = (TextView) findViewById(R.id.texteBarre);
        tB.setText("Creation de la soiree...");
        tB.setTextColor(Color.WHITE);
        tB.setTypeface(custFont);
        tB.setGravity(Gravity.CENTER);

        titre = (TextView) findViewById(R.id.titre);
        titre.setText("Plan de la soiree");
        titre.setTextColor(Color.WHITE);
        titre.setTypeface(custFont);
        titre.setGravity(Gravity.CENTER);

        boutonCarte = findViewById(R.id.voirCarte);
        boutonValider = findViewById(R.id.validerSoiree);

        db = new DBAdapter(this,"",null,1);

        aListe2 = db.list_adressesP(aListe);
        ArrayList<LatLng> arLat = new ArrayList<>();
        for(int j =0; j<aListe2.size(); j++) {
            arLat.add(getLocationFromAddress(this,aListe2.get(j).toString()));
        }
        rdv = computeCentroid(arLat);

        Geocoder geocoder = new Geocoder(displaySoiree.this, Locale.getDefault());

        List<Address> addresses  = null;
        try {
            addresses = geocoder.getFromLocation(rdv.latitude,rdv.longitude, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String city = addresses.get(0).getLocality();
        String street = addresses.get(0).getThoroughfare();
        if(street==null){
            street = "";
        }

        String streetNumb = addresses.get(0).getSubThoroughfare();
        if(streetNumb==null){
            streetNumb = "";
        }
        String state = addresses.get(0).getAdminArea();
        String zip = addresses.get(0).getPostalCode();
        String country = addresses.get(0).getCountryName();
        String knownName = addresses.get(0).getFeatureName();




        AppelApi appelApi=new AppelApi();
        appelApi.execute();


            arrayAdapter2 = new ArrayAdapter<String>(displaySoiree.this, android.R.layout.simple_selectable_list_item){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                ((TextView) v).setTextColor(R.color.fondET);
                ((TextView) v).setTypeface(custFont);
                ((TextView) v).setBackgroundColor(Color.CYAN);
                return v;
            }

            @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {
                // TODO Auto-generated method stub
                View v = super.getDropDownView(position, convertView, parent);
                ((TextView) v).setTextColor(R.color.fondET);
                ((TextView) v).setTypeface(custFont);
                ((TextView) v).setBackgroundColor(Color.WHITE);
                return v;
            }
        };

        /*for(int i =0; i<arLat.size(); i++) {
            arrayAdapter2.add("Lattitude : "+arLat.get(i).latitude+" Longitude : "+arLat.get(i).longitude);
        }*/




    }


    public LatLng getLocationFromAddress(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }

    private LatLng computeCentroid(List<LatLng> points) {
        double latitude = 0;
        double longitude = 0;
        int n = points.size();

        for (LatLng point : points) {
            latitude += point.latitude;
            longitude += point.longitude;
        }

        return new LatLng(latitude/n, longitude/n);
    }

    public void recapSoiree(View view) {
        AlertDialog.Builder dialog = new AlertDialog.Builder((displaySoiree.this));


        dialog.setTitle("Confirmation de la soiree");
        dialog.setMessage("Etes vous sur de vouloir valider cette soiree ?");



        dialog.setPositiveButton("Valider", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                SendMailTask sendMail =new SendMailTask();
                sendMail.execute();
                Intent intent = new Intent(displaySoiree.this, envoieMail.class);
                intent.putExtra("sam", sa);
                dialog.dismiss();
                startActivity(intent);
            }
        });

        dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialog.show();





    }


    private class AppelApi extends AsyncTask<Void, Integer, Void>
    {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();


        }

        @Override
        protected void onProgressUpdate(Integer... values){
            super.onProgressUpdate(values);
            pb.setProgress(values[0]);


        }

        @Override
        protected Void doInBackground(Void... arg0) {

            try {

                    String myurl = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" + rdv.latitude + "," + rdv.longitude + "&radius=500&type=restaurant&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs";

                    URL url = new URL(myurl);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.connect();
                    InputStream inputStream = connection.getInputStream();
                    Looper.prepare();
                    end = new ArrayList<>();
                    end2 = new ArrayList<>();
                    end3 = new ArrayList<>();

                    String result = InputStreamOperations.InputStreamToString(inputStream);

                    // On récupère le JSON complet
                    JSONObject j = new JSONObject(result);
                    while(j.getString("status").equalsIgnoreCase("ZERO_RESULTS")){
                        rad=rad*2;
                        myurl="https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" + rdv.latitude + "," + rdv.longitude + "&radius="+rad+"&type=restaurant&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs";
                        url = new URL(myurl);
                        connection = (HttpURLConnection) url.openConnection();
                        inputStream = connection.getInputStream();
                        result = InputStreamOperations.InputStreamToString(inputStream);
                        j= new JSONObject(result);
                    }
                    for (int i = 0; i < j.getJSONArray("results").length(); i++) {
                        JSONObject lieu = (j.getJSONArray("results")).getJSONObject(i);
                        JSONObject location = lieu.getJSONObject("geometry");



                        JSONObject loca = location.getJSONObject("location");
                       // nomRecup = lieu.getString("name");
                       // adresseRecup = lieu.getString("vicinity");

                        //end.set(i).setNomEndroit(lieu.getString("name"));

                        endroits e1 = new endroits();
                        e1.setNomEndroit(lieu.getString("name"));
                        e1.setEmplacement(lieu.getString("vicinity"));
                        try {
                            e1.setNote(Float.parseFloat((lieu.getString("rating"))));
                        } catch (Exception e){
                            e1.setNote((float) 0.0);
                        }
                        try {
                            JSONArray photos = lieu.getJSONArray("photos");
                            e1.setImageRef(photos.getJSONObject(0).getString("photo_reference"));
                        } catch (Exception e){
                            e1.setImageRef("");
                        }
                        e1.setLat(loca.getDouble("lat"));
                        e1.setLng(loca.getDouble("lng"));

                        end.add(e1);

                    }

                    int meil = getMaxNote(end);
                    pos1= end.get(meil).getLat();
                    pos2=end.get(meil).getLng();
                    try {
                        refIm = end.get(meil).getImageRef();
                    }catch(Exception e){}

                    String myurl2 = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" + pos1 + "," + pos2+ "&radius=500&type=bar&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs";
                    URL url2 = new URL(myurl2);
                    HttpURLConnection connection2 = (HttpURLConnection) url2.openConnection();
                    connection2.connect();
                    InputStream inputStream2 = connection2.getInputStream();

                    String result2 = InputStreamOperations.InputStreamToString(inputStream2);
                    JSONObject k = new JSONObject(result2);
                    while(k.getString("status").equalsIgnoreCase("ZERO_RESULTS")){
                        rad2=rad2*2;
                        myurl2="https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" + pos1+ "," + pos2 + "&radius="+rad2+"&type=bar&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs";
                        url2 = new URL(myurl2);
                        connection2 = (HttpURLConnection) url2.openConnection();
                        inputStream2 = connection2.getInputStream();
                        result2 = InputStreamOperations.InputStreamToString(inputStream2);
                        k= new JSONObject(result2);
                    }
                    for (int i = 0; i < k.getJSONArray("results").length(); i++) {
                        JSONObject lieu = (k.getJSONArray("results")).getJSONObject(i);
                        JSONObject location = lieu.getJSONObject("geometry");

                        JSONObject loca = location.getJSONObject("location");
                       /* nomRecup2 = lieu.getString("name");
                        adresseRecup2 = lieu.getString("vicinity");
                        pos1 = loca.getDouble("lat");
                        pos2 = loca.getDouble("lng");*/

                        endroits e1 = new endroits();
                        e1.setNomEndroit(lieu.getString("name"));
                        e1.setEmplacement(lieu.getString("vicinity"));
                        try {
                            e1.setNote(Float.parseFloat((lieu.getString("rating"))));
                        } catch (Exception e){
                            e1.setNote((float) 0.0);
                        }
                        try {
                            JSONArray photos = lieu.getJSONArray("photos");
                            e1.setImageRef(photos.getJSONObject(0).getString("photo_reference"));
                        } catch (Exception e){
                            e1.setImageRef("");
                        }
                        e1.setLat(loca.getDouble("lat"));
                        e1.setLng(loca.getDouble("lng"));

                        end2.add(e1);

                    }
                    int meil2 = getMaxNote(end2);
                    pos1= end2.get(meil2).getLat();
                    pos2= end2.get(meil2).getLng();
                    try {
                        refIm2 = end2.get(meil2).getImageRef();
                    }catch(Exception e){}

                    String myurl3 = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" + pos1 + "," + pos2+ "&radius=500&type=night_club&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs";
                    URL url3 = new URL(myurl3);
                    HttpURLConnection connection3 = (HttpURLConnection) url3.openConnection();
                    connection3.connect();
                    InputStream inputStream3 = connection3.getInputStream();

                    String result3 = InputStreamOperations.InputStreamToString(inputStream3);
                    JSONObject l = new JSONObject(result3);
                    while(l.getString("status").equalsIgnoreCase("ZERO_RESULTS")){
                        rad3=rad3*2;
                        myurl3="https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" + pos1 + "," + pos2 + "&radius="+rad3+"&type=night_club&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs";
                        url3 = new URL(myurl3);
                        connection3 = (HttpURLConnection) url3.openConnection();
                        inputStream3 = connection3.getInputStream();
                        result3 = InputStreamOperations.InputStreamToString(inputStream3);
                        l= new JSONObject(result3);
                    }
                    for (int i = 0; i < l.getJSONArray("results").length(); i++) {
                        JSONObject lieu = (l.getJSONArray("results")).getJSONObject(i);
                        JSONObject location = lieu.getJSONObject("geometry");

                        JSONObject loca = location.getJSONObject("location");
                        /*nomRecup3 = lieu.getString("name");
                        adresseRecup3 = lieu.getString("vicinity");
                        pos1 = loca.getDouble("lat");
                        pos2 = loca.getDouble("lng");*/
                        endroits e1 = new endroits();
                        e1.setNomEndroit(lieu.getString("name"));
                        e1.setEmplacement(lieu.getString("vicinity"));
                        try {
                            e1.setNote(Float.parseFloat((lieu.getString("rating"))));
                        } catch (Exception e){
                            e1.setNote((float) 0.0);
                        }
                        try {
                            JSONArray photos = lieu.getJSONArray("photos");
                            e1.setImageRef(photos.getJSONObject(0).getString("photo_reference"));
                        } catch (Exception e){
                            e1.setImageRef("");
                        }

                        e1.setLat(loca.getDouble("lat"));
                        e1.setLng(loca.getDouble("lng"));

                        end3.add(e1);
                    }
                     int meil3 = getMaxNote(end3);
                        try {
                            refIm3 = end3.get(meil3).getImageRef();
                        }catch(Exception e){}

                    try {
                        InputStream in = new URL("https://maps.googleapis.com/maps/api/place/photo?maxwidth=8000&photoreference=" + refIm + "&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs").openStream();
                        bmp = BitmapFactory.decodeStream(in);
                    }catch (Exception e){

                    }

                    try {
                        InputStream in2 = new URL("https://maps.googleapis.com/maps/api/place/photo?maxwidth=8000&photoreference=" + refIm2 + "&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs").openStream();
                        bmp2 = BitmapFactory.decodeStream(in2);
                    }catch (Exception e){}

                    try {
                        InputStream in3 = new URL("https://maps.googleapis.com/maps/api/place/photo?maxwidth=8000&photoreference=" + refIm3 + "&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs").openStream();
                        bmp3 = BitmapFactory.decodeStream(in3);
                    }catch (Exception e){}

                for(int P = 0; P <100; P++){
                    sleep(10);
                    publishProgress(P);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
                /*
                Toast.makeText(getApplicationContext(), "Le restaurant est : " + nomRecup + " et son adresse est :" + adresseRecup, Toast.LENGTH_LONG).show();

                Toast.makeText(getApplicationContext(), "Le bar est : " + nomRecup2 + " et son adresse est :" + adresseRecup2, Toast.LENGTH_LONG).show();

                Toast.makeText(getApplicationContext(), "La boite de nuit est : "+nomRecup3+" et son adresse est :"+adresseRecup3, Toast.LENGTH_LONG).show();*/
            pb.setVisibility(View.GONE);
            pb.setVisibility(View.INVISIBLE);
            tB.setVisibility(View.INVISIBLE);
            boutonCarte.setVisibility(View.VISIBLE);
            boutonValider.setVisibility(View.VISIBLE);

            int mNote = getMaxNote(end);
            int mNote2 = getMaxNote(end2);
            int mNote3 = getMaxNote(end3);

            nomRest = end.get(mNote).getNomEndroit();
            adresseRest = end.get(mNote).getEmplacement();

            nomBar = end2.get(mNote2).getNomEndroit();
            adresseBar = end2.get(mNote2).getEmplacement();

            nomBoite = end3.get(mNote3).getNomEndroit();
            adresseBoite = end3.get(mNote3).getEmplacement();

            nomRest=nomRest.replace('é','e');
            nomRest=nomRest.replace('è','e');
            nomRest=nomRest.replace('ô','o');
            adresseRest=adresseRest.replace('é','e');
            adresseRest=adresseRest.replace('è','e');
            adresseRest=adresseRest.replace('ô','o');

            nomBar=nomBar.replace('é','e');
            nomBar=nomBar.replace('è','e');
            nomBar=nomBar.replace('ô','o');
            adresseBar=adresseBar.replace('é','e');
            adresseBar=adresseBar.replace('è','e');
            adresseBar=adresseBar.replace('ô','o');

            nomBoite=nomBoite.replace('é','e');
            nomBoite=nomBoite.replace('è','e');
            nomBoite=nomBoite.replace('ô','o');
            adresseBoite=adresseBoite.replace('é','e');
            adresseBoite=adresseBoite.replace('è','e');
            adresseBoite=adresseBoite.replace('ô','o');


            /*arrayAdapter2.add("1ere etape : le restaurant " + nomRecup + " a l'adresse : " + adresseRecup);
            arrayAdapter2.add("2eme etape : le bar " + nomRecup2 + " a l'adresse : " + adresseRecup2);
            arrayAdapter2.add("3eme etape : la boite de nuit " + nomRecup3 + " a l'adresse : " + adresseRecup3);*/

            arrayAdapter2.add("1ere etape : le restaurant " + nomRest + " a l'adresse : " + adresseRest);
            arrayAdapter2.add("2eme etape : le bar " + nomBar + " a l'adresse : " + adresseBar);
            arrayAdapter2.add("3eme etape : la boite de nuit " + nomBoite + " a l'adresse : " + adresseBoite);




            lv.setAdapter(arrayAdapter2);
            lv.setClickable(true);
            dialog = new AlertDialog.Builder((displaySoiree.this));

            //            dialog.setTitle("Détails du lieu");



            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> arg0, View arg1, final int position, long arg3) {







                    dialog.setPositiveButton("Generer nouveau lieu", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(position==0) {
                                int note = getOtherNote(end, nomRest);
                                refIm = end.get(note).getImageRef();
                                appelChangeImage appel=new appelChangeImage();
                                appel.execute();



                                String nomRest2 = end.get(note).getNomEndroit();
                                String adresseRest2 = end.get(note).getEmplacement();
                                arrayAdapter2.remove(arrayAdapter2.getItem(position));
                                arrayAdapter2.insert("1ere etape : le restaurant " + nomRest2 + " a l'adresse : " + adresseRest2, position);
                                nomRest = nomRest2;
                                adresseRest = adresseRest2;
                                lv.setAdapter(arrayAdapter2);
                            }
                            else if(position==1){
                                int note = getOtherNote(end2, nomBar);
                                refIm2 = end2.get(note).getImageRef();
                                appelChangeImage2 appel=new appelChangeImage2();
                                appel.execute();


                                String nomBar2 = end2.get(note).getNomEndroit();
                                String adresseBar2 = end2.get(note).getEmplacement();
                                arrayAdapter2.remove(arrayAdapter2.getItem(position));
                                arrayAdapter2.insert("2eme etape : le bar " + nomBar2 + " a l'adresse : " + adresseBar2, position);
                                nomBar = nomBar2;
                                adresseBar = adresseBar2;
                                lv.setAdapter(arrayAdapter2);
                            }
                            else if(position==2){
                                int note = getOtherNote(end3, nomBoite);
                                refIm3 = end3.get(note).getImageRef();
                                appelChangeImage3 appel=new appelChangeImage3();
                                appel.execute();


                                String nomBoite2 = end3.get(note).getNomEndroit();
                                String adresseBoite2 = end3.get(note).getEmplacement();
                                arrayAdapter2.remove(arrayAdapter2.getItem(position));
                                arrayAdapter2.insert("3eme etape : la boite de nuit " + nomBoite2 + " a l'adresse : " + adresseBoite2, position);
                                nomBoite=nomBoite2;
                                adresseBoite = adresseBoite2;
                                lv.setAdapter(arrayAdapter2);
                            }
                            dialog.dismiss();
                        }
                    });
                    dialog.setNegativeButton("Retour", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    if(position==0 && bmp!=null) {
                        photoEndroit = new ImageView(displaySoiree.this);
                        photoEndroit.setImageBitmap(bmp);
                        photoEndroit.setScaleType(ImageView.ScaleType.FIT_XY);
                        dialog.setView(photoEndroit);

                    }
                    else if(position==0 &&bmp==null){
                        photoVide = new ImageView(displaySoiree.this);
                        photoVide.setImageResource(R.drawable.ph);
                        photoVide.setScaleType(ImageView.ScaleType.FIT_XY);
                        dialog.setView(photoVide);

                    }

                    if(position==1 && bmp2!=null){
                        photoEndroit2 = new ImageView(displaySoiree.this);
                            photoEndroit2.setImageBitmap(bmp2);
                        photoEndroit2.setScaleType(ImageView.ScaleType.FIT_XY);
                        dialog.setView(photoEndroit2);

                    }
                    else if(position==1 &&bmp2==null){
                        photoVide2 = new ImageView(displaySoiree.this);
                        photoVide2.setImageResource(R.drawable.ph);
                        photoVide2.setScaleType(ImageView.ScaleType.FIT_XY);
                        dialog.setView(photoVide2);

                    }

                    if(position==2 && bmp3!=null){
                        photoEndroit3 = new ImageView(displaySoiree.this);

                            photoEndroit3.setImageBitmap(bmp3);
                        photoEndroit3.setScaleType(ImageView.ScaleType.FIT_XY);
                        dialog.setView(photoEndroit3);
                    }
                    else if(position==2 &&bmp3==null){

                        photoVide3 = new ImageView(displaySoiree.this);
                        photoVide3.setImageResource(R.drawable.ph);
                        photoVide3.setScaleType(ImageView.ScaleType.FIT_XY);
                        dialog.setView(photoVide3);

                    }
                    dialog.show();


                }
            });
        }
    }

    class endroits {
        public String emplacement;
        public String nomEndroit;
        public float note;
        public double lat, lng;
        public String imageRef;

        public void setEmplacement(String e){
            this.emplacement = e;
        }

        public String getEmplacement(){
            return emplacement;
        }

        public void setNomEndroit(String n){
            this.nomEndroit = n;

        }

        public String getNomEndroit(){
            return nomEndroit;
        }

        public void setNote(float no){
            this.note = no;
        }

        public float getNote(){
            return note;
        }

        public  void setLat(double l){
            this.lat = l;
        }
        public double getLat(){
            return lat;
        }
        public void setLng(double ln){
            this.lng = ln;
        }
        public double getLng(){
            return lng;
        }

        public String getImageRef() {
            return imageRef;
        }

        public void setImageRef(String imageRef) {
            this.imageRef = imageRef;
        }
    }

    public int getMaxNote(ArrayList<endroits> end) {
        float maxValue = end.get(0).getNote();
        int iMax = 0;
        for (int i = 0; i < end.size(); i++) {
            if (end.get(i).getNote() > maxValue) {
                maxValue = end.get(i).getNote();
                iMax = i;
            }
        }
        return iMax;
    }

    public int getOtherNote(ArrayList<endroits> end, String champ) {
        if(end.size()>1) {
            for (int j = 0; j < end.size(); j++) {
                if (end.get(j).nomEndroit == champ) {
                    end.remove(j);
                }
            }
        }

        float maxValue = end.get(0).getNote();
        int iMax = 0;
        for (int i = 0; i < end.size(); i++) {
            if (end.get(i).getNote() > maxValue) {
                maxValue = end.get(i).getNote();
                iMax = i;
            }
        }
        return iMax;
    }

    class appelChangeImage extends AsyncTask<Void, Integer, Void> {



        @Override
        protected Void doInBackground(Void... voids) {
            try

            {
                InputStream in = null;
                in = new URL("https://maps.googleapis.com/maps/api/place/photo?maxwidth=8000&photoreference=" + refIm + "&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs").openStream();
                bmp = BitmapFactory.decodeStream(in);


            } catch(
                    IOException e)

            {
                e.printStackTrace();

            }
            return null;
        }


    }

    class appelChangeImage2 extends AsyncTask<Void, Integer, Void> {



        @Override
        protected Void doInBackground(Void... voids) {
            try

            {
                InputStream in = null;
                in = new URL("https://maps.googleapis.com/maps/api/place/photo?maxwidth=8000&photoreference=" + refIm2 + "&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs").openStream();
                bmp2 =BitmapFactory.decodeStream(in);
            } catch(
                    IOException e)

            {
                e.printStackTrace();
            }
            return null;
        }


    }

    class appelChangeImage3 extends AsyncTask<Void, Integer, Void> {



        @Override
        protected Void doInBackground(Void... voids) {
            try

            {
                InputStream in = null;
                in = new URL("https://maps.googleapis.com/maps/api/place/photo?maxwidth=8000&photoreference=" + refIm3 + "&key=AIzaSyAllYzccI_K7v4bjYvfXS4bRSx5dH5ShUs").openStream();
                bmp3 =BitmapFactory.decodeStream(in);
            } catch(
                    IOException e)

            {
                e.printStackTrace();
            }
            return null;
        }


    }

    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        }
        return false;
    }

    public class SendMailTask extends AsyncTask<Void, Integer, Void>
    {


        @Override
        protected Void doInBackground(Void... voids) {
            DBAdapter dbM = new DBAdapter(displaySoiree.this,"",null,1);
            aListeMail =dbM.list_adressesMail(aListe);
            Random r = new Random();
            int taille = aListe.size();
            int recup = r.nextInt(taille);
            sa= aListe.get(recup).toString();

            if(isOnline()) {
                Properties props = new Properties();
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.host", "smtp.gmail.com");
                props.put("mail.smtp.port", "587");

                final String username = "projectnighttrip@gmail.com";
                final String password = "leprojetgla";

                Session session = Session.getInstance(props,
                        new javax.mail.Authenticator() {
                            protected PasswordAuthentication getPasswordAuthentication() {
                                return new PasswordAuthentication(username, password);
                            }
                        });

                try {
                    MimeMessage message = new MimeMessage(session);
                    message.setFrom(new InternetAddress("projectnighttrip@gmail.com"));
                    for(int i = 0; i<aListeMail.size();i++) {
                        message.setRecipients(MimeMessage.RecipientType.TO,
                                InternetAddress.parse(aListeMail.get(i)));
                        message.setSubject("Recapitulatif de votre soiree");
                        message.setText("Salut " +aListe.get(i)+" !"
                                + "\n\nVoici le récapitulatif de votre soirée :"
                                + "\n\nTout d'abbord, vous irez vous remplir le bide au restaurant "+ nomRest+" situé à l'adresse "+adresseRest+"."
                                + "\n\nPuis, pour se mettre dans l'ambiance, nous vous proposons le bar "+ nomBar+" qui se trouve au "+adresseBar+"."
                                + "\n\nEnfin, pour finir la soirée en beauté vous irez à la boite de nuit "+ nomBoite+" à l'adresse "+adresseBoite+"."
                                + "\n\nConsommez avec modération, votre Sam désigné pour la soiree est "+ sa+ " !"
                                + "\n\nAmusez vous bien,"
                                + "\n\nL'équipe Night Trip.");

                        MimeBodyPart messageBodyPart = new MimeBodyPart();
                /*
                Multipart multipart = new MimeMultipart();

                messageBodyPart = new MimeBodyPart();
                String file = "path of file to be attached";
                String fileName = "attachmentName";
                DataSource source = new FileDataSource(file);
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(fileName);
                multipart.addBodyPart(messageBodyPart);

                message.setContent(multipart);*/

                        Transport.send(message);

                        System.out.println("Done");
                    }

                } catch (MessagingException e) {
                    throw new RuntimeException(e);
                }
            }


            return null;
        }
    }


}
